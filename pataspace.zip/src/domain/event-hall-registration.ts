import type { EventHallSystemPreparation } from './event-hall-system-preparation';
import type { PropertyLocationInput, PropertyOwnershipRole, PropertyRegistrationAction } from './property-registration';
import { canRegisterProperties } from './property-registration';
import type { UserRoleId } from './types';

export type HallCategoryId = 'wedding-hall' | 'meeting-hall' | 'training-hall' | 'church-event-hall' | 'party-hall' | 'community-hall' | 'general-event-hall';
export type HallRoadVisibilityId = 'facing-main-road' | 'along-main-road' | 'facing-inner-road' | 'along-inner-road' | 'inside-commercial-building' | 'inside-shopping-complex' | 'inside-estate' | 'other';
export type HallAvailabilityAnswer = 'yes' | 'no';
export type HallNearbyPlaceId = 'main-road' | 'bus-stage' | 'shopping-centre' | 'hotel' | 'hospital';

export interface HallCategoryOption { id: HallCategoryId; label: string; description: string }
export interface HallRoadVisibilityOption { id: HallRoadVisibilityId; label: string }
export interface HallNearbyPlaceDistanceInput { place: HallNearbyPlaceId; approximateDistance?: string }
export interface HallPhotoInput { fileName: string; represents?: 'Front of Property' | 'Hall Entrance' | 'Hall Interior' | 'Stage' | 'Seating Arrangement' | 'Gate' | 'Parking Area' | 'Surrounding Environment' }

export interface EventHallRegistrationInput {
  hallName: string;
  hallCategory?: HallCategoryId;
  location: PropertyLocationInput;
  roadVisibility: HallRoadVisibilityId;
  numberOfHalls: number | null;
  hallCapacity?: number | null;
  hallIdentifiers: string[];
  isAvailableForBookings: HallAvailabilityAnswer;
  bookingPrice?: number | null;
  additionalPricingArrangements?: string;
  nearbyPlaces: HallNearbyPlaceDistanceInput[];
  photos: HallPhotoInput[];
  description: string;
  ownershipRole: PropertyOwnershipRole;
  action: PropertyRegistrationAction;
}

export interface RegisteredEventHallFoundation extends EventHallRegistrationInput {
  id: string;
  propertyFoundationId: string;
  registeredByUserId: string;
  registeredByRole: UserRoleId;
  duplicateCandidateIds: string[];
  reviewFlags: string[];
  systemPreparation: EventHallSystemPreparation;
  createdAt: string;
  updatedAt: string;
  submittedAt?: string;
}

export const EVENT_HALL_REGISTRATION_FOUNDATION = {
  purpose: 'Collect and organize event hall information only.',
  authorizedRoles: ['property-owner', 'property-manager', 'leasing-agent'] as const,
  blockedRoles: ['customer'] as const,
  inheritsRegistrationUserExperienceStandard: true,
  hallMatchExcludesWaterInformation: true,
  hallMatchExcludesElectricityInformation: true,
  inheritsVacantUnitIdentification: true,
  successMessage: 'Your event hall has been successfully registered.',
  doesNotImplement: ['Hall Match', 'Verification', 'Search Ranking', 'Notifications', 'Reviews', 'Payments', 'AI Admin Assistant logic', 'Platform Health Monitor logic'] as const
} as const;

export const HALL_CATEGORIES: readonly HallCategoryOption[] = [
  { id: 'wedding-hall', label: 'Wedding Hall', description: 'A hall suitable for weddings and receptions.' },
  { id: 'meeting-hall', label: 'Meeting Hall', description: 'A hall suitable for meetings and formal gatherings.' },
  { id: 'training-hall', label: 'Training Hall', description: 'A hall suitable for trainings and workshops.' },
  { id: 'church-event-hall', label: 'Church Event Hall', description: 'A hall suitable for church or fellowship events.' },
  { id: 'party-hall', label: 'Party Hall', description: 'A hall suitable for parties and celebrations.' },
  { id: 'community-hall', label: 'Community Hall', description: 'A hall suitable for community events.' },
  { id: 'general-event-hall', label: 'General Event Hall', description: 'A general-purpose event hall.' }
] as const;

export const HALL_ROAD_VISIBILITY_OPTIONS: readonly HallRoadVisibilityOption[] = [
  { id: 'facing-main-road', label: 'Facing the Main Road' },
  { id: 'along-main-road', label: 'Along the Main Road' },
  { id: 'facing-inner-road', label: 'Facing an Inner Road' },
  { id: 'along-inner-road', label: 'Along an Inner Road' },
  { id: 'inside-commercial-building', label: 'Inside a Commercial Building' },
  { id: 'inside-shopping-complex', label: 'Inside a Shopping Complex' },
  { id: 'inside-estate', label: 'Inside an Estate' },
  { id: 'other', label: 'Other' }
] as const;

export const HALL_NEARBY_PLACES = [
  { id: 'main-road', label: 'Main Road' },
  { id: 'bus-stage', label: 'Bus Stage' },
  { id: 'shopping-centre', label: 'Shopping Centre' },
  { id: 'hotel', label: 'Hotel' },
  { id: 'hospital', label: 'Hospital' }
] as const;

export const HALL_PHOTO_GUIDANCE = ['Front of the property', 'Hall entrance', 'Hall interior', 'Stage if available', 'Seating arrangement', 'Gate', 'Parking area', 'Surrounding environment'] as const;
export function canRegisterEventHalls(role: UserRoleId): boolean { return canRegisterProperties(role); }
