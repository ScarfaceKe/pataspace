import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { DASHBOARD_ROUTES } from '@/domain/auth';
import { getProfileFromSessionCookie } from './service';
import { SESSION_COOKIE_NAME } from './session';

export async function requireCurrentUser(expectedRoute?: string) {
  const cookieStore = await cookies();
  const profile = await getProfileFromSessionCookie(cookieStore.get(SESSION_COOKIE_NAME)?.value);
  if (!profile) redirect('/auth/login');
  const correctRoute = DASHBOARD_ROUTES[profile.role];
  if (expectedRoute && correctRoute !== expectedRoute) redirect(correctRoute);
  return profile;
}
