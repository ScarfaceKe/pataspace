import { NextResponse } from 'next/server';
import { getProfileFromSessionCookie } from './service';
import { extractCookieValue } from './request-security';

export async function requireApiUser(request: Request) {
  const profile = await getProfileFromSessionCookie(extractCookieValue(request));
  if (!profile) {
    return { ok: false as const, response: NextResponse.json({ ok: false, message: 'Please log in to continue.' }, { status: 401 }) };
  }
  return { ok: true as const, profile };
}
