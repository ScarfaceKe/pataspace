'use client';

import { PropertyLocationVerificationStep } from '@/components/properties/PropertyLocationVerificationStep';
import { ListingWhatsAppSupport } from '@/components/support/ListingWhatsAppSupport';
import type { PropertyLocationVerification } from '@/domain/location-verification';
import { useState } from 'react';
import { KENYA_COUNTIES, KNOWN_KENYA_LOCATION_TERMS } from '@/domain/kenya-location-intelligence';
import { getRegistrationResponsibilityCopy, type PropertyOwnershipRole, type PropertyRegistrationAction } from '@/domain/property-registration';
import {
  OFFICE_DEPOSIT_STRUCTURES,
  OFFICE_NEARBY_PLACES,
  OFFICE_PHOTO_GUIDANCE,
  OFFICE_REGISTRATION_FOUNDATION,
  OFFICE_ROAD_VISIBILITY_OPTIONS,
  OFFICE_TYPES,
  OFFICE_WATER_AVAILABILITY_OPTIONS,
  officeWaterHasConnection,
  type OfficeDepositStructureId,
  type OfficeNearbyPlaceId,
  type OfficeRoadVisibilityId,
  type OfficeTypeId,
  type OfficeWaterAvailabilityId,
  type OfficeWaterRentInclusion
} from '@/domain/office-registration';
import type { UserRoleId } from '@/domain/types';
import { summarizeImageUploadResults, uploadPropertyImageFiles } from '@/components/properties/propertyImageUploadClient';

const totalSteps = 11;
function toNumberOrNull(value: string): number | null { if (!value.trim()) return null; const parsed = Number(value); return Number.isFinite(parsed) ? parsed : null; }

export function OfficeRegistrationForm({ profileRole }: { profileRole: UserRoleId }) {
  const defaultOwnership: PropertyOwnershipRole = profileRole === 'property-owner' ? 'owner' : profileRole === 'leasing-agent' ? 'leasing-agent' : 'property-manager';
  const [step, setStep] = useState(1);
  const [locationVerification, setLocationVerification] = useState<PropertyLocationVerification | undefined>();
  const [officeType, setOfficeType] = useState<OfficeTypeId>('private-office');
  const [county, setCounty] = useState('');
  const [townOrCity, setTownOrCity] = useState('');
  const [estateOrArea, setEstateOrArea] = useState('');
  const [landmark, setLandmark] = useState('');
  const [roadVisibility, setRoadVisibility] = useState<OfficeRoadVisibilityId>('inside-office-building');
  const [officeName, setOfficeName] = useState('');
  const [numberOfOfficeUnits, setNumberOfOfficeUnits] = useState('');
  const [numberOfFloors, setNumberOfFloors] = useState('');
  const [vacantOfficeFloor, setVacantOfficeFloor] = useState('');
  const [monthlyRent, setMonthlyRent] = useState('');
  const [depositStructure, setDepositStructure] = useState<OfficeDepositStructureId>('one-month');
  const [depositAmount, setDepositAmount] = useState('');
  const [hasVacantOfficeUnits, setHasVacantOfficeUnits] = useState<'yes' | 'no'>('yes');
  const [vacancyMonthlyRent, setVacancyMonthlyRent] = useState('');
  const [vacancyDepositStructure, setVacancyDepositStructure] = useState<OfficeDepositStructureId>('one-month');
  const [vacancyDepositAmount, setVacancyDepositAmount] = useState('');
  const [quantityAvailable, setQuantityAvailable] = useState('1');
  const [unitIdentifiers, setUnitIdentifiers] = useState('');
  const [waterAvailability, setWaterAvailability] = useState<OfficeWaterAvailabilityId>('daily-water');
  const [specificDays, setSpecificDays] = useState('');
  const [waterRentInclusion, setWaterRentInclusion] = useState<OfficeWaterRentInclusion>('included');
  const [isElectricityAvailable, setIsElectricityAvailable] = useState<'yes' | 'no'>('yes');
  const [electricityBillingType, setElectricityBillingType] = useState<'individual-meter' | 'shared-meter' | 'included-in-rent' | 'other'>('individual-meter');
  const [electricityOtherBilling, setElectricityOtherBilling] = useState('');
  const [powerAvailabilityNotes, setPowerAvailabilityNotes] = useState('');
  const [nearbyPlaces, setNearbyPlaces] = useState<Record<OfficeNearbyPlaceId, string>>({ 'bus-stage': '', 'main-road': '', 'shopping-centre': '', bank: '', hospital: '' });
  const [photoNames, setPhotoNames] = useState<string[]>([]);
  const [photoFiles, setPhotoFiles] = useState<File[]>([]);
  const [description, setDescription] = useState('');
  const [ownershipRole, setOwnershipRole] = useState<PropertyOwnershipRole>(defaultOwnership);
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [savingAction, setSavingAction] = useState<PropertyRegistrationAction | null>(null);

  async function save(action: PropertyRegistrationAction) {
    setSavingAction(action); setErrors({}); setMessage(action === 'save-draft' ? 'Saving your office draft...' : 'Submitting office property...');
    const response = await fetch('/api/offices/register', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        officeType,
        location: { county, townOrCity, estateOrAreaOrNeighbourhood: estateOrArea, landmark, verification: locationVerification },
        roadVisibility,
        officeName,
        numberOfOfficeUnits: toNumberOrNull(numberOfOfficeUnits),
        numberOfFloors: toNumberOrNull(numberOfFloors),
        vacantOfficeFloor: toNumberOrNull(vacantOfficeFloor),
        rent: { monthlyRent: toNumberOrNull(monthlyRent), depositStructure, depositAmount: toNumberOrNull(depositAmount) },
        hasVacantOfficeUnits,
        vacancy: hasVacantOfficeUnits === 'yes' ? {
          monthlyRent: toNumberOrNull(vacancyMonthlyRent),
          depositStructure: vacancyDepositStructure,
          depositAmount: toNumberOrNull(vacancyDepositAmount),
          quantityAvailable: toNumberOrNull(quantityAvailable),
          unitIdentifiers: unitIdentifiers.split(/[\n,]+/).map((item) => item.trim()).filter(Boolean)
        } : undefined,
        water: { availability: waterAvailability, specificDays, rentInclusion: officeWaterHasConnection(waterAvailability) ? waterRentInclusion : undefined },
        electricity: { isElectricityAvailable, billingType: isElectricityAvailable === 'yes' ? electricityBillingType : undefined, otherBillingDescription: electricityBillingType === 'other' ? electricityOtherBilling : undefined, powerAvailabilityNotes },
        nearbyPlaces: Object.entries(nearbyPlaces).filter(([, approximateDistance]) => approximateDistance.trim()).map(([place, approximateDistance]) => ({ place, approximateDistance })),
        photos: photoNames.map((fileName) => ({ fileName })),
        description,
        ownershipRole,
        action
      })
    });
    const result = await response.json(); setSavingAction(null);
    if (!response.ok) { setErrors(result.fieldErrors ?? {}); setMessage(result.message ?? 'Please check the highlighted details and try again.'); return; }
    let imageUploadSummary = '';
    if (result.office?.propertyFoundationId && photoFiles.length) {
      const uploadResults = await uploadPropertyImageFiles({ propertyId: result.office.propertyFoundationId, files: photoFiles, onProgress: setMessage });
      imageUploadSummary = summarizeImageUploadResults(uploadResults);
    }
    setMessage(`${action === 'submit-registration' ? `${OFFICE_REGISTRATION_FOUNDATION.successMessage} ${hasVacantOfficeUnits === 'yes' ? 'If vacancies exist, they will proceed to future platform workflows.' : 'If no vacancies exist, the property remains registered until vacancies become available.'}` : result.message}${imageUploadSummary ? ` ${imageUploadSummary}` : ''}`);
  }

  return (
    <section className="property-registration-card" aria-labelledby="office-registration-title">
      <div className="auth-header"><span className="section-eyebrow">Office registration</span><h1 id="office-registration-title">Register an office property</h1><p>{getRegistrationResponsibilityCopy(profileRole)} This guided workflow collects approved office information only.</p></div>
      <ListingWhatsAppSupport context="listing" />
      <div className="progress-steps" aria-label="Office registration progress">{Array.from({ length: totalSteps }, (_, index) => index + 1).map((item) => <button key={item} type="button" className={step === item ? 'step active' : 'step'} onClick={() => setStep(item)} aria-current={step === item ? 'step' : undefined}>{item}</button>)}</div>

      {step === 1 ? <section className="auth-step"><h2>What type of office space are you registering?</h2><div className="property-category-grid">{OFFICE_TYPES.map((item) => <button key={item.id} type="button" className={officeType === item.id ? 'property-category-card active' : 'property-category-card'} onClick={() => setOfficeType(item.id)} aria-pressed={officeType === item.id}><strong>{item.label}</strong><small>{item.description}</small></button>)}</div>{errors.officeType ? <p className="field-error">{errors.officeType}</p> : null}</section> : null}

      {step === 2 ? <section className="auth-step"><h2>Property Location</h2><label className="field-label">County<input list="kenya-counties" value={county} onChange={(e) => setCounty(e.target.value)} placeholder="Nairobi" />{errors.county ? <span>{errors.county}</span> : null}</label><label className="field-label">Town / City<input list="known-kenya-locations" value={townOrCity} onChange={(e) => setTownOrCity(e.target.value)} placeholder="Nairobi" />{errors.townOrCity ? <span>{errors.townOrCity}</span> : null}</label><label className="field-label">Estate / Area<input list="known-kenya-locations" value={estateOrArea} onChange={(e) => setEstateOrArea(e.target.value)} placeholder="Westlands" />{errors.estateOrArea ? <span>{errors.estateOrArea}</span> : null}</label><label className="field-label">Landmark (optional)<input value={landmark} onChange={(e) => setLandmark(e.target.value)} placeholder="Near a known landmark" /></label><ListingWhatsAppSupport context="location" /><PropertyLocationVerificationStep value={locationVerification} onChange={setLocationVerification} onSuggestedAddress={(suggested) => { if (suggested.county && !county) setCounty(suggested.county); if (suggested.town && !townOrCity) setTownOrCity(suggested.town); if (suggested.estate && !estateOrArea) setEstateOrArea(suggested.estate); if (suggested.road && !landmark) setLandmark(suggested.road); }} /><datalist id="kenya-counties">{KENYA_COUNTIES.map((item) => <option key={item} value={item} />)}</datalist><datalist id="known-kenya-locations">{KNOWN_KENYA_LOCATION_TERMS.map((item) => <option key={item} value={item} />)}</datalist></section> : null}

      {step === 3 ? <section className="auth-step"><h2>Where is the office located?</h2><fieldset className="selection-fieldset"><legend>Road visibility</legend>{OFFICE_ROAD_VISIBILITY_OPTIONS.map((item) => <label key={item.id}><input type="radio" name="officeRoadVisibility" checked={roadVisibility === item.id} onChange={() => setRoadVisibility(item.id)} /> {item.label}</label>)}</fieldset>{errors.roadVisibility ? <p className="field-error">{errors.roadVisibility}</p> : null}</section> : null}

      {step === 4 ? <section className="auth-step"><h2>Office Information</h2><label className="field-label">Office Name (optional)<input value={officeName} onChange={(e) => setOfficeName(e.target.value)} /></label><label className="field-label">Number of Office Units<input type="number" min="1" value={numberOfOfficeUnits} onChange={(e) => setNumberOfOfficeUnits(e.target.value)} />{errors.numberOfOfficeUnits ? <span>{errors.numberOfOfficeUnits}</span> : null}</label><label className="field-label">Number of Floors (if applicable)<input type="number" min="1" value={numberOfFloors} onChange={(e) => setNumberOfFloors(e.target.value)} />{errors.numberOfFloors ? <span>{errors.numberOfFloors}</span> : null}</label>{hasVacantOfficeUnits === 'yes' ? <label className="field-label">Floor where vacant office exists (if applicable)<input type="number" min="0" value={vacantOfficeFloor} onChange={(e) => setVacantOfficeFloor(e.target.value)} />{errors.vacantOfficeFloor ? <span>{errors.vacantOfficeFloor}</span> : null}</label> : null}</section> : null}

      {step === 5 ? <section className="auth-step"><h2>Rent Information</h2><label className="field-label">Monthly Rent<input type="number" min="0" value={monthlyRent} onChange={(e) => setMonthlyRent(e.target.value)} placeholder="Amount in KSh" />{errors.monthlyRent ? <span>{errors.monthlyRent}</span> : null}</label><fieldset className="selection-fieldset"><legend>Deposit Amount</legend>{OFFICE_DEPOSIT_STRUCTURES.map((item) => <label key={item.id}><input type="radio" name="officeDeposit" checked={depositStructure === item.id} onChange={() => setDepositStructure(item.id)} /> {item.label}</label>)}</fieldset><label className="field-label">Deposit amount entered directly<input type="number" min="0" value={depositAmount} onChange={(e) => setDepositAmount(e.target.value)} placeholder="Do not restrict deposit values" />{errors.depositAmount ? <span>{errors.depositAmount}</span> : null}</label></section> : null}

      {step === 6 ? <section className="auth-step"><h2>Vacancy Information</h2><fieldset className="selection-fieldset"><legend>Are there currently vacant office units?</legend><label><input type="radio" name="hasVacantOfficeUnits" checked={hasVacantOfficeUnits === 'yes'} onChange={() => setHasVacantOfficeUnits('yes')} /> Yes</label><label><input type="radio" name="hasVacantOfficeUnits" checked={hasVacantOfficeUnits === 'no'} onChange={() => setHasVacantOfficeUnits('no')} /> No</label></fieldset>{hasVacantOfficeUnits === 'no' ? <p className="auth-message">The office property can be registered without publishing vacancies.</p> : null}{hasVacantOfficeUnits === 'yes' ? <div className="vacancy-foundation-panel"><label className="field-label">Monthly Rent<input type="number" min="0" value={vacancyMonthlyRent} onChange={(e) => setVacancyMonthlyRent(e.target.value)} />{errors.vacancyMonthlyRent ? <span>{errors.vacancyMonthlyRent}</span> : null}</label><fieldset className="selection-fieldset"><legend>Vacancy deposit</legend>{OFFICE_DEPOSIT_STRUCTURES.map((item) => <label key={item.id}><input type="radio" name="officeVacancyDeposit" checked={vacancyDepositStructure === item.id} onChange={() => setVacancyDepositStructure(item.id)} /> {item.label}</label>)}</fieldset><label className="field-label">Deposit<input type="number" min="0" value={vacancyDepositAmount} onChange={(e) => setVacancyDepositAmount(e.target.value)} />{errors.vacancyDepositAmount ? <span>{errors.vacancyDepositAmount}</span> : null}</label><label className="field-label">Quantity Available<input type="number" min="1" value={quantityAvailable} onChange={(e) => setQuantityAvailable(e.target.value)} />{errors.quantityAvailable ? <span>{errors.quantityAvailable}</span> : null}</label><label className="field-label">Real-world vacant office identifiers<textarea className="large-description-field" rows={3} value={unitIdentifiers} onChange={(e) => setUnitIdentifiers(e.target.value)} placeholder="Enter each actual office identifier exactly as it appears, for example Office 203, Unit 12 or A1." />{errors.unitIdentifiers ? <span>{errors.unitIdentifiers}</span> : null}</label></div> : null}</section> : null}

      {step === 7 ? <section className="auth-step"><h2>Water Information</h2><fieldset className="selection-fieldset"><legend>Water availability</legend>{OFFICE_WATER_AVAILABILITY_OPTIONS.map((item) => <label key={item.id}><input type="radio" name="officeWater" checked={waterAvailability === item.id} onChange={() => setWaterAvailability(item.id)} /> {item.label}</label>)}</fieldset>{waterAvailability === 'specific-days' ? <label className="field-label">Which days is water available?<input value={specificDays} onChange={(e) => setSpecificDays(e.target.value)} />{errors.specificDays ? <span>{errors.specificDays}</span> : null}</label> : null}{officeWaterHasConnection(waterAvailability) ? <fieldset className="selection-fieldset"><legend>Is water included in the rent?</legend><label><input type="radio" name="officeWaterRent" checked={waterRentInclusion === 'included'} onChange={() => setWaterRentInclusion('included')} /> Included</label><label><input type="radio" name="officeWaterRent" checked={waterRentInclusion === 'paid-separately'} onChange={() => setWaterRentInclusion('paid-separately')} /> Paid Separately</label></fieldset> : null}</section> : null}

      {step === 8 ? <section className="auth-step"><h2>Electricity Information</h2><fieldset className="selection-fieldset"><legend>Is electricity available?</legend><label><input type="radio" name="officeElectricity" checked={isElectricityAvailable === 'yes'} onChange={() => setIsElectricityAvailable('yes')} /> Yes</label><label><input type="radio" name="officeElectricity" checked={isElectricityAvailable === 'no'} onChange={() => setIsElectricityAvailable('no')} /> No</label></fieldset>{isElectricityAvailable === 'yes' ? <div className="vacancy-foundation-panel"><fieldset className="selection-fieldset"><legend>How is electricity billed?</legend><label><input type="radio" name="officeElectricityBilling" checked={electricityBillingType === 'individual-meter'} onChange={() => setElectricityBillingType('individual-meter')} /> Individual Meter</label><label><input type="radio" name="officeElectricityBilling" checked={electricityBillingType === 'shared-meter'} onChange={() => setElectricityBillingType('shared-meter')} /> Shared Meter</label><label><input type="radio" name="officeElectricityBilling" checked={electricityBillingType === 'included-in-rent'} onChange={() => setElectricityBillingType('included-in-rent')} /> Included in Rent</label><label><input type="radio" name="officeElectricityBilling" checked={electricityBillingType === 'other'} onChange={() => setElectricityBillingType('other')} /> Other</label></fieldset>{electricityBillingType === 'other' ? <label className="field-label">Briefly describe the billing arrangement<input value={electricityOtherBilling} onChange={(e) => setElectricityOtherBilling(e.target.value)} />{errors.electricityOtherBilling ? <span>{errors.electricityOtherBilling}</span> : null}</label> : null}<label className="field-label">Power availability notes, if necessary<textarea className="large-description-field" rows={3} value={powerAvailabilityNotes} onChange={(e) => setPowerAvailabilityNotes(e.target.value)} placeholder="Add useful information about electricity supply." /></label></div> : null}</section> : null}

      {step === 9 ? <section className="auth-step"><h2>Nearby Places</h2><p className="small-note">Add approximate distances where known. This information becomes part of future Office Match.</p><div className="nearby-grid">{OFFICE_NEARBY_PLACES.map((item) => <label className="field-label" key={item.id}>{item.label}<input value={nearbyPlaces[item.id]} onChange={(e) => setNearbyPlaces((current) => ({ ...current, [item.id]: e.target.value }))} placeholder="e.g. 200m or 3 minutes walk" /></label>)}</div></section> : null}

      {step === 10 ? <section className="auth-step"><h2>Property Photos</h2><label className="field-label">Upload office photos<input type="file" accept="image/*" multiple onChange={(e) => { const files = Array.from(e.target.files ?? []); setPhotoFiles(files); setPhotoNames(files.map((file) => file.name)); }} /></label><ul className="photo-guidance-list">{OFFICE_PHOTO_GUIDANCE.map((item) => <li key={item}>{item}</li>)}</ul>{photoNames.length ? <ul className="uploaded-photo-list">{photoNames.map((name) => <li key={name}>{name}</li>)}</ul> : null}</section> : null}

      {step === 11 ? <section className="auth-step"><h2>Property Description</h2><label className="field-label">Accurate and honest office description<textarea className="large-description-field" rows={7} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Describe the office, access, surroundings, building condition and suitability. Avoid exaggerated marketing language." />{errors.description ? <span>{errors.description}</span> : null}</label><fieldset className="selection-fieldset"><legend>Registration relationship</legend><label><input type="radio" name="officeOwnershipRole" checked={ownershipRole === 'owner'} onChange={() => setOwnershipRole('owner')} /> I am the Owner</label><label><input type="radio" name="officeOwnershipRole" checked={ownershipRole === 'property-manager'} onChange={() => setOwnershipRole('property-manager')} /> I am the Property Manager</label><label><input type="radio" name="officeOwnershipRole" checked={ownershipRole === 'leasing-agent'} onChange={() => setOwnershipRole('leasing-agent')} /> I am the Leasing Agent</label></fieldset></section> : null}

      <div className="auth-actions">{step > 1 ? <button type="button" className="secondary-action" onClick={() => setStep(step - 1)}>Back</button> : null}{step < totalSteps ? <button type="button" className="primary-action" onClick={() => setStep(step + 1)}>Continue</button> : null}<button type="button" className="secondary-action" onClick={() => save('save-draft')} disabled={savingAction !== null}>{savingAction === 'save-draft' ? 'Saving draft...' : 'Save as Draft'}</button><button type="button" className="secondary-action" onClick={() => save('save-draft')} disabled={savingAction !== null}>Continue Later</button>{step === totalSteps ? <button type="button" className="primary-action" onClick={() => save('submit-registration')} disabled={savingAction !== null}>{savingAction === 'submit-registration' ? 'Submitting...' : 'Submit Registration'}</button> : null}</div>
      {message ? <div className="auth-message" role="status" aria-live="polite">{message}</div> : null}
    </section>
  );
}
