'use client';

import { PropertyLocationVerificationStep } from '@/components/properties/PropertyLocationVerificationStep';
import { ListingWhatsAppSupport } from '@/components/support/ListingWhatsAppSupport';
import type { PropertyLocationVerification } from '@/domain/location-verification';
import { useState } from 'react';
import { KENYA_COUNTIES, KNOWN_KENYA_LOCATION_TERMS } from '@/domain/kenya-location-intelligence';
import { getRegistrationResponsibilityCopy, type PropertyOwnershipRole, type PropertyRegistrationAction } from '@/domain/property-registration';
import {
  BUSINESS_SUITABILITY_OPTIONS,
  COMMERCIAL_UNIT_TYPES,
  ROAD_VISIBILITY_OPTIONS,
  SHOP_DEPOSIT_STRUCTURES,
  SHOP_NEARBY_PLACES,
  SHOP_PHOTO_GUIDANCE,
  SHOP_PRICING_CATEGORIES,
  SHOP_REGISTRATION_FOUNDATION,
  SHOP_TYPES,
  SHOP_WATER_AVAILABILITY_OPTIONS,
  shopWaterHasConnection,
  type BusinessSuitabilityId,
  type CommercialUnitTypeId,
  type DepositStructureId,
  type RoadVisibilityId,
  type ShopNearbyPlaceId,
  type ShopPricingCategoryId,
  type ShopTypeId,
  type ShopWaterAvailabilityId,
  type ShopWaterRentInclusion
} from '@/domain/shop-registration';
import type { UserRoleId } from '@/domain/types';
import { summarizeImageUploadResults, uploadPropertyImageFiles } from '@/components/properties/propertyImageUploadClient';

interface ShopRegistrationFormProps {
  profileRole: UserRoleId;
}

const totalSteps = 12;

function toNumberOrNull(value: string): number | null {
  if (!value.trim()) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

export function ShopRegistrationForm({ profileRole }: ShopRegistrationFormProps) {
  const defaultOwnership: PropertyOwnershipRole =
    profileRole === 'property-owner' ? 'owner' : profileRole === 'leasing-agent' ? 'leasing-agent' : 'property-manager';
  const [step, setStep] = useState(1);
  const [locationVerification, setLocationVerification] = useState<PropertyLocationVerification | undefined>();
  const [shopType, setShopType] = useState<ShopTypeId>('retail-shop');
  const [commercialUnitType, setCommercialUnitType] = useState<CommercialUnitTypeId>('shop');
  const [customCommercialUnitType, setCustomCommercialUnitType] = useState('');
  const [pricingCategory, setPricingCategory] = useState<ShopPricingCategoryId>('medium-shop');
  const [county, setCounty] = useState('');
  const [townOrCity, setTownOrCity] = useState('');
  const [estateOrArea, setEstateOrArea] = useState('');
  const [landmark, setLandmark] = useState('');
  const [roadVisibility, setRoadVisibility] = useState<RoadVisibilityId>('facing-main-road');
  const [shopName, setShopName] = useState('');
  const [numberOfShopUnits, setNumberOfShopUnits] = useState('');
  const [numberOfFloors, setNumberOfFloors] = useState('');
  const [vacantShopFloor, setVacantShopFloor] = useState('');
  const [monthlyRent, setMonthlyRent] = useState('');
  const [depositStructure, setDepositStructure] = useState<DepositStructureId>('one-month');
  const [depositAmount, setDepositAmount] = useState('');
  const [hasVacantShopUnits, setHasVacantShopUnits] = useState<'yes' | 'no'>('yes');
  const [vacancyMonthlyRent, setVacancyMonthlyRent] = useState('');
  const [vacancyDepositStructure, setVacancyDepositStructure] = useState<DepositStructureId>('one-month');
  const [vacancyDepositAmount, setVacancyDepositAmount] = useState('');
  const [quantityAvailable, setQuantityAvailable] = useState('1');
  const [unitIdentifiers, setUnitIdentifiers] = useState('');
  const [waterAvailability, setWaterAvailability] = useState<ShopWaterAvailabilityId>('daily-water');
  const [specificDays, setSpecificDays] = useState('');
  const [waterRentInclusion, setWaterRentInclusion] = useState<ShopWaterRentInclusion>('included');
  const [isElectricityAvailable, setIsElectricityAvailable] = useState<'yes' | 'no'>('yes');
  const [electricityBillingType, setElectricityBillingType] = useState<'individual-meter' | 'shared-meter' | 'included-in-rent' | 'other'>('individual-meter');
  const [electricityOtherBilling, setElectricityOtherBilling] = useState('');
  const [powerAvailabilityNotes, setPowerAvailabilityNotes] = useState('');
  const [businessSuitability, setBusinessSuitability] = useState<BusinessSuitabilityId[]>([]);
  const [nearbyPlaces, setNearbyPlaces] = useState<Record<ShopNearbyPlaceId, string>>({
    'bus-stage': '',
    market: '',
    'main-road': '',
    'shopping-centre': '',
    bank: '',
    hospital: ''
  });
  const [photoNames, setPhotoNames] = useState<string[]>([]);
  const [photoFiles, setPhotoFiles] = useState<File[]>([]);
  const [description, setDescription] = useState('');
  const [ownershipRole, setOwnershipRole] = useState<PropertyOwnershipRole>(defaultOwnership);
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [savingAction, setSavingAction] = useState<PropertyRegistrationAction | null>(null);

  function toggleBusiness(id: BusinessSuitabilityId) {
    setBusinessSuitability((current) => current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  }

  function selectPhotos(fileList: FileList | null) {
    if (!fileList) return;
    const files = Array.from(fileList);
    setPhotoFiles(files);
    setPhotoNames(files.map((file) => file.name));
  }

  async function save(action: PropertyRegistrationAction) {
    setSavingAction(action);
    setErrors({});
    setMessage(action === 'save-draft' ? 'Saving your shop draft...' : 'Submitting shop property...');

    const response = await fetch('/api/shops/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        shopType,
        commercialUnitType,
        customCommercialUnitType,
        pricingCategory,
        location: { county, townOrCity, estateOrAreaOrNeighbourhood: estateOrArea, landmark, verification: locationVerification },
        roadVisibility,
        shopName,
        numberOfShopUnits: toNumberOrNull(numberOfShopUnits),
        numberOfFloors: toNumberOrNull(numberOfFloors),
        vacantShopFloor: toNumberOrNull(vacantShopFloor),
        rent: { monthlyRent: toNumberOrNull(monthlyRent), depositStructure, depositAmount: toNumberOrNull(depositAmount) },
        hasVacantShopUnits,
        vacancy: hasVacantShopUnits === 'yes' ? {
          monthlyRent: toNumberOrNull(vacancyMonthlyRent),
          depositStructure: vacancyDepositStructure,
          depositAmount: toNumberOrNull(vacancyDepositAmount),
          quantityAvailable: toNumberOrNull(quantityAvailable),
          unitIdentifiers: unitIdentifiers.split(/[\n,]+/).map((item) => item.trim()).filter(Boolean)
        } : undefined,
        water: {
          availability: waterAvailability,
          specificDays,
          rentInclusion: shopWaterHasConnection(waterAvailability) ? waterRentInclusion : undefined
        },
        electricity: {
          isElectricityAvailable,
          billingType: isElectricityAvailable === 'yes' ? electricityBillingType : undefined,
          otherBillingDescription: electricityBillingType === 'other' ? electricityOtherBilling : undefined,
          powerAvailabilityNotes
        },
        businessSuitability,
        nearbyPlaces: Object.entries(nearbyPlaces)
          .filter(([, approximateDistance]) => approximateDistance.trim())
          .map(([place, approximateDistance]) => ({ place, approximateDistance })),
        photos: photoNames.map((fileName) => ({ fileName })),
        description,
        ownershipRole,
        action
      })
    });

    const result = await response.json();
    setSavingAction(null);
    if (!response.ok) {
      setErrors(result.fieldErrors ?? {});
      setMessage(result.message ?? 'Please check the highlighted details and try again.');
      return;
    }
    let imageUploadSummary = '';
    if (result.shop?.propertyFoundationId && photoFiles.length) {
      const uploadResults = await uploadPropertyImageFiles({ propertyId: result.shop.propertyFoundationId, files: photoFiles, onProgress: setMessage });
      imageUploadSummary = summarizeImageUploadResults(uploadResults);
    }
    setMessage(
      action === 'submit-registration'
        ? `${SHOP_REGISTRATION_FOUNDATION.successMessage} ${hasVacantShopUnits === 'yes' ? 'If vacancies exist, they will be prepared for later workflows.' : 'If vacancies do not exist, the shop remains registered until vacancies are published.'}`
        : result.message
    );
    if (imageUploadSummary) setMessage((current) => `${current} ${imageUploadSummary}`);
  }

  return (
    <section className="property-registration-card" aria-labelledby="shop-registration-title">
      <div className="auth-header">
        <span className="section-eyebrow">Shop registration</span>
        <h1 id="shop-registration-title">Register a commercial shop space</h1>
        <p>{getRegistrationResponsibilityCopy(profileRole)} This guided workflow collects approved shop information only.</p>
      </div>

      <ListingWhatsAppSupport context="listing" />

      <div className="progress-steps" aria-label="Shop registration progress">
        {Array.from({ length: totalSteps }, (_, index) => index + 1).map((item) => (
          <button key={item} type="button" className={step === item ? 'step active' : 'step'} onClick={() => setStep(item)} aria-current={step === item ? 'step' : undefined}>{item}</button>
        ))}
      </div>

      {step === 1 ? (
        <section className="auth-step" aria-labelledby="shop-type-title">
          <h2 id="shop-type-title">What type of shop are you registering?</h2>
          <div className="property-category-grid">
            {SHOP_TYPES.map((item) => (
              <button key={item.id} type="button" className={shopType === item.id ? 'property-category-card active' : 'property-category-card'} onClick={() => setShopType(item.id)} aria-pressed={shopType === item.id}>
                <strong>{item.label}</strong>
                <small>{item.description}</small>
              </button>
            ))}
          </div>
          {errors.shopType ? <p className="field-error">{errors.shopType}</p> : null}
          <h2>Commercial Unit Type Identification</h2>
          <p className="small-note">Commercial Unit Type describes the nature of the space for search, matching, filtering, and display. It does not determine pricing.</p>
          <div className="business-toggle-grid">
            {COMMERCIAL_UNIT_TYPES.map((item) => (
              <button key={item.id} type="button" className={commercialUnitType === item.id ? 'business-toggle active' : 'business-toggle'} onClick={() => setCommercialUnitType(item.id)} aria-pressed={commercialUnitType === item.id}>
                <strong>{item.label}</strong>
                <small>{item.description}</small>
              </button>
            ))}
          </div>
          {commercialUnitType === 'other-commercial-unit-type' ? (
            <label className="field-label">Custom commercial unit type
              <input value={customCommercialUnitType} onChange={(event) => setCustomCommercialUnitType(event.target.value)} placeholder="Enter the commercial unit type" />
              {errors.customCommercialUnitType ? <span>{errors.customCommercialUnitType}</span> : null}
            </label>
          ) : null}
          {errors.commercialUnitType ? <p className="field-error">{errors.commercialUnitType}</p> : null}
          <h2>Pricing Category</h2>
          <p className="small-note">Pricing Category is used only for centrally managed Founder-approved Unlock This Listing and Verified Access pricing.</p>
          <fieldset className="selection-fieldset">
            <legend>Choose the platform pricing category</legend>
            {SHOP_PRICING_CATEGORIES.map((item) => (
              <label key={item.id}><input type="radio" name="shopPricingCategory" checked={pricingCategory === item.id} onChange={() => setPricingCategory(item.id)} /> {item.label}</label>
            ))}
          </fieldset>
          {errors.pricingCategory ? <p className="field-error">{errors.pricingCategory}</p> : null}
        </section>
      ) : null}

      {step === 2 ? (
        <section className="auth-step" aria-labelledby="shop-location-title">
          <h2 id="shop-location-title">Property Location</h2>
          <label className="field-label">County
            <input list="kenya-counties" value={county} onChange={(event) => setCounty(event.target.value)} placeholder="Nairobi" />
            {errors.county ? <span>{errors.county}</span> : null}
          </label>
          <label className="field-label">Town / City
            <input list="known-kenya-locations" value={townOrCity} onChange={(event) => setTownOrCity(event.target.value)} placeholder="Nairobi" />
            {errors.townOrCity ? <span>{errors.townOrCity}</span> : null}
          </label>
          <label className="field-label">Estate / Area
            <input list="known-kenya-locations" value={estateOrArea} onChange={(event) => setEstateOrArea(event.target.value)} placeholder="Westlands" />
            {errors.estateOrArea ? <span>{errors.estateOrArea}</span> : null}
          </label>
          <label className="field-label">Landmark (optional)
            <input value={landmark} onChange={(event) => setLandmark(event.target.value)} placeholder="Near a known landmark" />
          </label>

          <ListingWhatsAppSupport context="location" />
          <PropertyLocationVerificationStep
            value={locationVerification}
            onChange={setLocationVerification}
            onSuggestedAddress={(suggested) => {
              if (suggested.county && !county) setCounty(suggested.county);
              if (suggested.town && !townOrCity) setTownOrCity(suggested.town);
              if (suggested.estate && !estateOrArea) setEstateOrArea(suggested.estate);
              if (suggested.road && !landmark) setLandmark(suggested.road);
            }}
          />
          <datalist id="kenya-counties">{KENYA_COUNTIES.map((item) => <option key={item} value={item} />)}</datalist>
          <datalist id="known-kenya-locations">{KNOWN_KENYA_LOCATION_TERMS.map((item) => <option key={item} value={item} />)}</datalist>
        </section>
      ) : null}

      {step === 3 ? (
        <section className="auth-step" aria-labelledby="road-visibility-title">
          <h2 id="road-visibility-title">Where is the shop located?</h2>
          <fieldset className="selection-fieldset">
            <legend>Road visibility</legend>
            {ROAD_VISIBILITY_OPTIONS.map((item) => (
              <label key={item.id}><input type="radio" name="roadVisibility" checked={roadVisibility === item.id} onChange={() => setRoadVisibility(item.id)} /> {item.label}</label>
            ))}
          </fieldset>
          {errors.roadVisibility ? <p className="field-error">{errors.roadVisibility}</p> : null}
        </section>
      ) : null}

      {step === 4 ? (
        <section className="auth-step" aria-labelledby="shop-info-title">
          <h2 id="shop-info-title">Shop Information</h2>
          <label className="field-label">Shop Name (optional)
            <input value={shopName} onChange={(event) => setShopName(event.target.value)} />
          </label>
          <label className="field-label">Number of Shop Units
            <input type="number" min="1" inputMode="numeric" value={numberOfShopUnits} onChange={(event) => setNumberOfShopUnits(event.target.value)} />
            {errors.numberOfShopUnits ? <span>{errors.numberOfShopUnits}</span> : null}
          </label>
          <label className="field-label">Number of Floors (if applicable)
            <input type="number" min="1" inputMode="numeric" value={numberOfFloors} onChange={(event) => setNumberOfFloors(event.target.value)} />
            {errors.numberOfFloors ? <span>{errors.numberOfFloors}</span> : null}
          </label>
          {hasVacantShopUnits === 'yes' ? (
            <label className="field-label">Floor where vacant shop exists (if applicable)
              <input type="number" min="0" inputMode="numeric" value={vacantShopFloor} onChange={(event) => setVacantShopFloor(event.target.value)} />
              {errors.vacantShopFloor ? <span>{errors.vacantShopFloor}</span> : null}
            </label>
          ) : null}
        </section>
      ) : null}

      {step === 5 ? (
        <section className="auth-step" aria-labelledby="shop-rent-title">
          <h2 id="shop-rent-title">Rent Information</h2>
          <label className="field-label">Monthly Rent
            <input type="number" min="0" inputMode="numeric" value={monthlyRent} onChange={(event) => setMonthlyRent(event.target.value)} placeholder="Amount in KSh" />
            {errors.monthlyRent ? <span>{errors.monthlyRent}</span> : null}
          </label>
          <fieldset className="selection-fieldset">
            <legend>Deposit Amount</legend>
            {SHOP_DEPOSIT_STRUCTURES.map((item) => (
              <label key={item.id}><input type="radio" name="depositStructure" checked={depositStructure === item.id} onChange={() => setDepositStructure(item.id)} /> {item.label}</label>
            ))}
          </fieldset>
          <label className="field-label">Deposit amount entered directly
            <input type="number" min="0" inputMode="numeric" value={depositAmount} onChange={(event) => setDepositAmount(event.target.value)} placeholder="Any custom deposit amount" />
            {errors.depositAmount ? <span>{errors.depositAmount}</span> : null}
          </label>
        </section>
      ) : null}

      {step === 6 ? (
        <section className="auth-step" aria-labelledby="shop-vacancy-title">
          <h2 id="shop-vacancy-title">Vacancy Information</h2>
          <fieldset className="selection-fieldset">
            <legend>Are there currently vacant shop units?</legend>
            <label><input type="radio" name="hasVacantShopUnits" checked={hasVacantShopUnits === 'yes'} onChange={() => setHasVacantShopUnits('yes')} /> Yes</label>
            <label><input type="radio" name="hasVacantShopUnits" checked={hasVacantShopUnits === 'no'} onChange={() => setHasVacantShopUnits('no')} /> No</label>
          </fieldset>
          {hasVacantShopUnits === 'no' ? <p className="auth-message">The shop property can be registered without publishing vacancies.</p> : null}
          {hasVacantShopUnits === 'yes' ? (
            <div className="vacancy-foundation-panel">
              <label className="field-label">Monthly Rent
                <input type="number" min="0" inputMode="numeric" value={vacancyMonthlyRent} onChange={(event) => setVacancyMonthlyRent(event.target.value)} />
                {errors.vacancyMonthlyRent ? <span>{errors.vacancyMonthlyRent}</span> : null}
              </label>
              <fieldset className="selection-fieldset">
                <legend>Vacancy deposit</legend>
                {SHOP_DEPOSIT_STRUCTURES.map((item) => (
                  <label key={item.id}><input type="radio" name="vacancyDepositStructure" checked={vacancyDepositStructure === item.id} onChange={() => setVacancyDepositStructure(item.id)} /> {item.label}</label>
                ))}
              </fieldset>
              <label className="field-label">Deposit amount filled directly
                <input type="number" min="0" inputMode="numeric" value={vacancyDepositAmount} onChange={(event) => setVacancyDepositAmount(event.target.value)} />
                {errors.vacancyDepositAmount ? <span>{errors.vacancyDepositAmount}</span> : null}
              </label>
              <label className="field-label">Quantity Available
                <input type="number" min="1" inputMode="numeric" value={quantityAvailable} onChange={(event) => setQuantityAvailable(event.target.value)} />
                {errors.quantityAvailable ? <span>{errors.quantityAvailable}</span> : null}
              </label>
              <label className="field-label">Real-world vacant shop identifiers
                <textarea className="large-description-field" rows={3} value={unitIdentifiers} onChange={(event) => setUnitIdentifiers(event.target.value)} placeholder="Enter each actual shop identifier exactly as it appears, for example Shop 14, Stall 3, K7 or Unit 12." />
                {errors.unitIdentifiers ? <span>{errors.unitIdentifiers}</span> : null}
              </label>
            </div>
          ) : null}
        </section>
      ) : null}

      {step === 7 ? (
        <section className="auth-step" aria-labelledby="shop-water-title">
          <h2 id="shop-water-title">Water Information</h2>
          <fieldset className="selection-fieldset">
            <legend>Water availability</legend>
            {SHOP_WATER_AVAILABILITY_OPTIONS.map((item) => (
              <label key={item.id}><input type="radio" name="shopWater" checked={waterAvailability === item.id} onChange={() => setWaterAvailability(item.id)} /> {item.label}</label>
            ))}
          </fieldset>
          {waterAvailability === 'specific-days' ? (
            <label className="field-label">Which days is water available?
              <input value={specificDays} onChange={(event) => setSpecificDays(event.target.value)} placeholder="For example: Monday, Wednesday and Saturday" />
              {errors.specificDays ? <span>{errors.specificDays}</span> : null}
            </label>
          ) : null}
          {shopWaterHasConnection(waterAvailability) ? (
            <fieldset className="selection-fieldset">
              <legend>Is water included in the rent?</legend>
              <label><input type="radio" name="shopWaterRentInclusion" checked={waterRentInclusion === 'included'} onChange={() => setWaterRentInclusion('included')} /> Included</label>
              <label><input type="radio" name="shopWaterRentInclusion" checked={waterRentInclusion === 'paid-separately'} onChange={() => setWaterRentInclusion('paid-separately')} /> Paid Separately</label>
            </fieldset>
          ) : null}
        </section>
      ) : null}

      {step === 8 ? (
        <section className="auth-step" aria-labelledby="shop-electricity-title">
          <h2 id="shop-electricity-title">Electricity Information</h2>
          <fieldset className="selection-fieldset"><legend>Is electricity available?</legend><label><input type="radio" name="shopElectricity" checked={isElectricityAvailable === 'yes'} onChange={() => setIsElectricityAvailable('yes')} /> Yes</label><label><input type="radio" name="shopElectricity" checked={isElectricityAvailable === 'no'} onChange={() => setIsElectricityAvailable('no')} /> No</label></fieldset>
          {isElectricityAvailable === 'yes' ? <div className="vacancy-foundation-panel"><fieldset className="selection-fieldset"><legend>How is electricity billed?</legend><label><input type="radio" name="shopElectricityBilling" checked={electricityBillingType === 'individual-meter'} onChange={() => setElectricityBillingType('individual-meter')} /> Individual Meter</label><label><input type="radio" name="shopElectricityBilling" checked={electricityBillingType === 'shared-meter'} onChange={() => setElectricityBillingType('shared-meter')} /> Shared Meter</label><label><input type="radio" name="shopElectricityBilling" checked={electricityBillingType === 'included-in-rent'} onChange={() => setElectricityBillingType('included-in-rent')} /> Included in Rent</label><label><input type="radio" name="shopElectricityBilling" checked={electricityBillingType === 'other'} onChange={() => setElectricityBillingType('other')} /> Other</label></fieldset>{electricityBillingType === 'other' ? <label className="field-label">Briefly describe the billing arrangement<input value={electricityOtherBilling} onChange={(event) => setElectricityOtherBilling(event.target.value)} />{errors.electricityOtherBilling ? <span>{errors.electricityOtherBilling}</span> : null}</label> : null}<label className="field-label">Power availability notes, if necessary<textarea className="large-description-field" rows={3} value={powerAvailabilityNotes} onChange={(event) => setPowerAvailabilityNotes(event.target.value)} placeholder="Add useful information about electricity supply." /></label></div> : null}
        </section>
      ) : null}

      {step === 9 ? (
        <section className="auth-step" aria-labelledby="business-suitability-title">
          <h2 id="business-suitability-title">Which businesses is the shop suitable for?</h2>
          <div className="business-toggle-grid">
            {BUSINESS_SUITABILITY_OPTIONS.map((item) => (
              <button key={item.id} type="button" className={businessSuitability.includes(item.id) ? 'business-toggle active' : 'business-toggle'} onClick={() => toggleBusiness(item.id)} aria-pressed={businessSuitability.includes(item.id)}>
                <strong>{item.label}</strong>
                <small>{item.example}</small>
              </button>
            ))}
          </div>
          {errors.businessSuitability ? <p className="field-error">{errors.businessSuitability}</p> : null}
        </section>
      ) : null}

      {step === 10 ? (
        <section className="auth-step" aria-labelledby="shop-nearby-title">
          <h2 id="shop-nearby-title">Nearby Places</h2>
          <p className="small-note">Add approximate distances where known. This information becomes searchable during Shop Match.</p>
          <div className="nearby-grid">
            {SHOP_NEARBY_PLACES.map((item) => (
              <label className="field-label" key={item.id}>{item.label}
                <input value={nearbyPlaces[item.id]} onChange={(event) => setNearbyPlaces((current) => ({ ...current, [item.id]: event.target.value }))} placeholder="e.g. 200m or 3 minutes walk" />
              </label>
            ))}
          </div>
        </section>
      ) : null}

      {step === 11 ? (
        <section className="auth-step" aria-labelledby="shop-photos-title">
          <h2 id="shop-photos-title">Property Photos</h2>
          <label className="field-label">Upload shop photos
            <input type="file" accept="image/*" multiple onChange={(event) => selectPhotos(event.target.files)} />
          </label>
          <ul className="photo-guidance-list">{SHOP_PHOTO_GUIDANCE.map((item) => <li key={item}>{item}</li>)}</ul>
          {photoNames.length ? <ul className="uploaded-photo-list">{photoNames.map((name) => <li key={name}>{name}</li>)}</ul> : null}
        </section>
      ) : null}

      {step === 12 ? (
        <section className="auth-step" aria-labelledby="shop-description-title">
          <h2 id="shop-description-title">Property Description</h2>
          <label className="field-label">Clear, honest shop description
            <textarea className="large-description-field" rows={7} value={description} onChange={(event) => setDescription(event.target.value)} placeholder="Describe the shop, access, road visibility, nearby businesses, condition and surroundings. Avoid exaggerated marketing language." />
            {errors.description ? <span>{errors.description}</span> : null}
          </label>
          <fieldset className="selection-fieldset">
            <legend>Registration relationship</legend>
            <label><input type="radio" name="ownershipRole" checked={ownershipRole === 'owner'} onChange={() => setOwnershipRole('owner')} /> I am the Owner</label>
            <label><input type="radio" name="ownershipRole" checked={ownershipRole === 'property-manager'} onChange={() => setOwnershipRole('property-manager')} /> I am the Property Manager</label>
            <label><input type="radio" name="ownershipRole" checked={ownershipRole === 'leasing-agent'} onChange={() => setOwnershipRole('leasing-agent')} /> I am the Leasing Agent</label>
          </fieldset>
        </section>
      ) : null}

      <div className="auth-actions">
        {step > 1 ? <button type="button" className="secondary-action" onClick={() => setStep(step - 1)}>Back</button> : null}
        {step < totalSteps ? <button type="button" className="primary-action" onClick={() => setStep(step + 1)}>Continue</button> : null}
        <button type="button" className="secondary-action" onClick={() => save('save-draft')} disabled={savingAction !== null}>{savingAction === 'save-draft' ? 'Saving draft...' : 'Save Draft'}</button>
        <button type="button" className="secondary-action" onClick={() => save('save-draft')} disabled={savingAction !== null}>Continue Later</button>
        {step === totalSteps ? <button type="button" className="primary-action" onClick={() => save('submit-registration')} disabled={savingAction !== null}>{savingAction === 'submit-registration' ? 'Submitting...' : 'Submit Registration'}</button> : null}
      </div>

      {message ? <div className="auth-message" role="status" aria-live="polite">{message}</div> : null}
    </section>
  );
}
