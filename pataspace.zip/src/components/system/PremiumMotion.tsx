'use client';

import { useEffect } from 'react';

const REVEAL_SELECTOR = [
  '.hero-copy',
  '.entry-panel',
  '.mission-card',
  '.content-section',
  '.guided-card',
  '.property-registration-card',
  '.auth-card',
  '.dashboard-card',
  '.info-card',
  '.property-result-card',
  '.review-summary-card',
  '.profile-summary > div',
  '.dashboard-actions > *',
  '.customer-choice-card'
].join(',');

function prefersReducedMotion(): boolean {
  return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
}

function shouldUseLiteMotion(): boolean {
  const connection = (navigator as Navigator & { connection?: { saveData?: boolean; effectiveType?: string } }).connection;
  return Boolean(connection?.saveData || connection?.effectiveType === '2g' || navigator.hardwareConcurrency <= 4);
}

export function PremiumMotion() {
  useEffect(() => {
    document.documentElement.classList.add('motion-ready');
    if (shouldUseLiteMotion()) document.documentElement.classList.add('motion-lite');
    if (prefersReducedMotion()) {
      document.documentElement.classList.add('motion-reduced');
      return;
    }

    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            entry.target.classList.add('motion-visible');
            observer.unobserve(entry.target);
          }
        }
      },
      { rootMargin: '0px 0px -8% 0px', threshold: 0.08 }
    );

    const prepare = (root: ParentNode = document) => {
      root.querySelectorAll(REVEAL_SELECTOR).forEach((element, index) => {
        if (!(element instanceof HTMLElement) || element.dataset.motionReveal === 'true') return;
        element.dataset.motionReveal = 'true';
        element.style.setProperty('--motion-order', String(Math.min(index % 8, 7)));
        observer.observe(element);
      });
    };

    prepare();
    const mutationObserver = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        mutation.addedNodes.forEach((node) => {
          if (node instanceof HTMLElement) prepare(node);
        });
      }
    });
    mutationObserver.observe(document.body, { childList: true, subtree: true });

    return () => {
      observer.disconnect();
      mutationObserver.disconnect();
    };
  }, []);

  return null;
}
