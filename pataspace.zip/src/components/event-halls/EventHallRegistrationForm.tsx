'use client';

import { PropertyLocationVerificationStep } from '@/components/properties/PropertyLocationVerificationStep';
import { ListingWhatsAppSupport } from '@/components/support/ListingWhatsAppSupport';
import type { PropertyLocationVerification } from '@/domain/location-verification';
import { useState } from 'react';
import {
  EVENT_HALL_REGISTRATION_FOUNDATION,
  HALL_CATEGORIES,
  HALL_NEARBY_PLACES,
  HALL_PHOTO_GUIDANCE,
  HALL_ROAD_VISIBILITY_OPTIONS,
  type HallAvailabilityAnswer,
  type HallCategoryId,
  type HallNearbyPlaceId,
  type HallRoadVisibilityId
} from '@/domain/event-hall-registration';
import { KENYA_COUNTIES, KNOWN_KENYA_LOCATION_TERMS } from '@/domain/kenya-location-intelligence';
import { getRegistrationResponsibilityCopy, type PropertyOwnershipRole, type PropertyRegistrationAction } from '@/domain/property-registration';
import type { UserRoleId } from '@/domain/types';
import { summarizeImageUploadResults, uploadPropertyImageFiles } from '@/components/properties/propertyImageUploadClient';

const totalSteps = 9;
function toNumberOrNull(value: string): number | null { if (!value.trim()) return null; const parsed = Number(value); return Number.isFinite(parsed) ? parsed : null; }

export function EventHallRegistrationForm({ profileRole }: { profileRole: UserRoleId }) {
  const defaultOwnership: PropertyOwnershipRole = profileRole === 'property-owner' ? 'owner' : profileRole === 'leasing-agent' ? 'leasing-agent' : 'property-manager';
  const [step, setStep] = useState(1);
  const [locationVerification, setLocationVerification] = useState<PropertyLocationVerification | undefined>();
  const [hallName, setHallName] = useState('');
  const [hallCategory, setHallCategory] = useState<HallCategoryId>('general-event-hall');
  const [county, setCounty] = useState('');
  const [townOrCity, setTownOrCity] = useState('');
  const [estateOrArea, setEstateOrArea] = useState('');
  const [landmark, setLandmark] = useState('');
  const [roadVisibility, setRoadVisibility] = useState<HallRoadVisibilityId>('inside-commercial-building');
  const [numberOfHalls, setNumberOfHalls] = useState('');
  const [hallCapacity, setHallCapacity] = useState('');
  const [hallIdentifiers, setHallIdentifiers] = useState('');
  const [isAvailableForBookings, setIsAvailableForBookings] = useState<HallAvailabilityAnswer>('yes');
  const [bookingPrice, setBookingPrice] = useState('');
  const [additionalPricingArrangements, setAdditionalPricingArrangements] = useState('');
  const [nearbyPlaces, setNearbyPlaces] = useState<Record<HallNearbyPlaceId, string>>({ 'main-road': '', 'bus-stage': '', 'shopping-centre': '', hotel: '', hospital: '' });
  const [photoNames, setPhotoNames] = useState<string[]>([]);
  const [photoFiles, setPhotoFiles] = useState<File[]>([]);
  const [description, setDescription] = useState('');
  const [ownershipRole, setOwnershipRole] = useState<PropertyOwnershipRole>(defaultOwnership);
  const [message, setMessage] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [savingAction, setSavingAction] = useState<PropertyRegistrationAction | null>(null);

  async function save(action: PropertyRegistrationAction) {
    setSavingAction(action);
    setErrors({});
    setMessage(action === 'save-draft' ? 'Saving your event hall draft...' : 'Submitting event hall...');
    const response = await fetch('/api/event-halls/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        hallName,
        hallCategory,
        location: { county, townOrCity, estateOrAreaOrNeighbourhood: estateOrArea, landmark, verification: locationVerification },
        roadVisibility,
        numberOfHalls: toNumberOrNull(numberOfHalls),
        hallCapacity: toNumberOrNull(hallCapacity),
        hallIdentifiers: hallIdentifiers.split(/[\n,]+/).map((x) => x.trim()).filter(Boolean),
        isAvailableForBookings,
        bookingPrice: toNumberOrNull(bookingPrice),
        additionalPricingArrangements,
        nearbyPlaces: Object.entries(nearbyPlaces).filter(([, approximateDistance]) => approximateDistance.trim()).map(([place, approximateDistance]) => ({ place, approximateDistance })),
        photos: photoNames.map((fileName) => ({ fileName })),
        description,
        ownershipRole,
        action
      })
    });
    const result = await response.json();
    setSavingAction(null);
    if (!response.ok) { setErrors(result.fieldErrors ?? {}); setMessage(result.message ?? 'Please check the highlighted details and try again.'); return; }
    let imageUploadSummary = '';
    if (result.eventHall?.propertyFoundationId && photoFiles.length) {
      const uploadResults = await uploadPropertyImageFiles({ propertyId: result.eventHall.propertyFoundationId, files: photoFiles, onProgress: setMessage });
      imageUploadSummary = summarizeImageUploadResults(uploadResults);
    }
    setMessage(`${action === 'submit-registration' ? `${EVENT_HALL_REGISTRATION_FOUNDATION.successMessage} ${isAvailableForBookings === 'yes' ? 'If available for bookings, it proceeds to future platform workflows.' : 'If unavailable, it remains registered until availability is updated.'}` : result.message}${imageUploadSummary ? ` ${imageUploadSummary}` : ''}`);
  }

  return <section className="property-registration-card" aria-labelledby="hall-registration-title">
    <div className="auth-header"><span className="section-eyebrow">Event hall registration</span><h1 id="hall-registration-title">Register an event hall</h1><p>{getRegistrationResponsibilityCopy(profileRole)} This guided workflow inherits PataSpace's choice-first registration standard.</p></div>
    <ListingWhatsAppSupport context="listing" />
    <div className="progress-steps" aria-label="Event hall registration progress">{Array.from({ length: totalSteps }, (_, i) => i + 1).map((n) => <button key={n} type="button" className={step === n ? 'step active' : 'step'} onClick={() => setStep(n)} aria-current={step === n ? 'step' : undefined}>{n}</button>)}</div>

    {step === 1 ? <section className="auth-step"><h2>Hall Information</h2><label className="field-label">Hall Name<input value={hallName} onChange={(e) => setHallName(e.target.value)} />{errors.hallName ? <span>{errors.hallName}</span> : null}</label><div className="property-category-grid">{HALL_CATEGORIES.map((item) => <button key={item.id} type="button" className={hallCategory === item.id ? 'property-category-card active' : 'property-category-card'} onClick={() => setHallCategory(item.id)}><strong>{item.label}</strong><small>{item.description}</small></button>)}</div></section> : null}
    {step === 2 ? <section className="auth-step"><h2>Property Location</h2><label className="field-label">County<input list="kenya-counties" value={county} onChange={(e) => setCounty(e.target.value)} />{errors.county ? <span>{errors.county}</span> : null}</label><label className="field-label">Town / City<input list="known-kenya-locations" value={townOrCity} onChange={(e) => setTownOrCity(e.target.value)} />{errors.townOrCity ? <span>{errors.townOrCity}</span> : null}</label><label className="field-label">Estate / Area<input list="known-kenya-locations" value={estateOrArea} onChange={(e) => setEstateOrArea(e.target.value)} />{errors.estateOrArea ? <span>{errors.estateOrArea}</span> : null}</label><label className="field-label">Landmark (optional)<input value={landmark} onChange={(e) => setLandmark(e.target.value)} /></label><ListingWhatsAppSupport context="location" /><PropertyLocationVerificationStep value={locationVerification} onChange={setLocationVerification} onSuggestedAddress={(suggested) => { if (suggested.county && !county) setCounty(suggested.county); if (suggested.town && !townOrCity) setTownOrCity(suggested.town); if (suggested.estate && !estateOrArea) setEstateOrArea(suggested.estate); if (suggested.road && !landmark) setLandmark(suggested.road); }} /><datalist id="kenya-counties">{KENYA_COUNTIES.map((item) => <option key={item} value={item} />)}</datalist><datalist id="known-kenya-locations">{KNOWN_KENYA_LOCATION_TERMS.map((item) => <option key={item} value={item} />)}</datalist></section> : null}
    {step === 3 ? <section className="auth-step"><h2>Where is the event hall located?</h2><fieldset className="selection-fieldset"><legend>Road visibility</legend>{HALL_ROAD_VISIBILITY_OPTIONS.map((item) => <label key={item.id}><input type="radio" name="hallRoadVisibility" checked={roadVisibility === item.id} onChange={() => setRoadVisibility(item.id)} /> {item.label}</label>)}</fieldset></section> : null}
    {step === 4 ? <section className="auth-step"><h2>Hall Details</h2><label className="field-label">Number of Halls available<input type="number" min="1" value={numberOfHalls} onChange={(e) => setNumberOfHalls(e.target.value)} />{errors.numberOfHalls ? <span>{errors.numberOfHalls}</span> : null}</label><label className="field-label">Hall Capacity (where applicable)<input type="number" min="1" value={hallCapacity} onChange={(e) => setHallCapacity(e.target.value)} />{errors.hallCapacity ? <span>{errors.hallCapacity}</span> : null}</label><label className="field-label">Real-world hall identifiers<textarea className="large-description-field" rows={3} value={hallIdentifiers} onChange={(e) => setHallIdentifiers(e.target.value)} placeholder="Enter each actual hall identifier exactly as it appears, for example Hall A, Hall B or Main Hall." />{errors.hallIdentifiers ? <span>{errors.hallIdentifiers}</span> : null}</label></section> : null}
    {step === 5 ? <section className="auth-step"><h2>Availability</h2><fieldset className="selection-fieldset"><legend>Is this hall currently available for bookings?</legend><label><input type="radio" name="hallAvailability" checked={isAvailableForBookings === 'yes'} onChange={() => setIsAvailableForBookings('yes')} /> Yes</label><label><input type="radio" name="hallAvailability" checked={isAvailableForBookings === 'no'} onChange={() => setIsAvailableForBookings('no')} /> No</label></fieldset>{isAvailableForBookings === 'no' ? <p className="auth-message">The hall can be registered without making it available for customer searches.</p> : null}</section> : null}
    {step === 6 ? <section className="auth-step"><h2>Pricing</h2>{isAvailableForBookings === 'yes' ? <label className="field-label">Hall Booking Price<input type="number" min="0" value={bookingPrice} onChange={(e) => setBookingPrice(e.target.value)} />{errors.bookingPrice ? <span>{errors.bookingPrice}</span> : null}</label> : null}<label className="field-label">Additional pricing arrangements, if any<textarea className="large-description-field" rows={3} value={additionalPricingArrangements} onChange={(e) => setAdditionalPricingArrangements(e.target.value)} /></label></section> : null}
    {step === 7 ? <section className="auth-step"><h2>Nearby Places</h2><div className="nearby-grid">{HALL_NEARBY_PLACES.map((item) => <label key={item.id} className="field-label">{item.label}<input value={nearbyPlaces[item.id]} onChange={(e) => setNearbyPlaces((current) => ({ ...current, [item.id]: e.target.value }))} placeholder="e.g. 300m or 5 minutes walk" /></label>)}</div></section> : null}
    {step === 8 ? <section className="auth-step"><h2>Property Photos</h2><label className="field-label">Upload event hall photos<input type="file" accept="image/*" multiple onChange={(e) => { const files = Array.from(e.target.files ?? []); setPhotoFiles(files); setPhotoNames(files.map((file) => file.name)); }} /></label><ul className="photo-guidance-list">{HALL_PHOTO_GUIDANCE.map((item) => <li key={item}>{item}</li>)}</ul>{photoNames.length ? <ul className="uploaded-photo-list">{photoNames.map((name) => <li key={name}>{name}</li>)}</ul> : null}</section> : null}
    {step === 9 ? <section className="auth-step"><h2>Property Description</h2><label className="field-label">Honest and accurate event hall description<textarea className="large-description-field" rows={7} value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Describe the hall, capacity, location, accessibility, parking, stage setup, seating arrangement, surroundings and condition. Avoid exaggerated marketing language." />{errors.description ? <span>{errors.description}</span> : null}</label><fieldset className="selection-fieldset"><legend>Registration relationship</legend><label><input type="radio" name="hallOwnership" checked={ownershipRole === 'owner'} onChange={() => setOwnershipRole('owner')} /> I am the Owner</label><label><input type="radio" name="hallOwnership" checked={ownershipRole === 'property-manager'} onChange={() => setOwnershipRole('property-manager')} /> I am the Property Manager</label><label><input type="radio" name="hallOwnership" checked={ownershipRole === 'leasing-agent'} onChange={() => setOwnershipRole('leasing-agent')} /> I am the Leasing Agent</label></fieldset></section> : null}
    <div className="auth-actions">{step > 1 ? <button type="button" className="secondary-action" onClick={() => setStep(step - 1)}>Back</button> : null}{step < totalSteps ? <button type="button" className="primary-action" onClick={() => setStep(step + 1)}>Continue</button> : null}<button type="button" className="secondary-action" onClick={() => save('save-draft')} disabled={savingAction !== null}>{savingAction === 'save-draft' ? 'Saving draft...' : 'Save as Draft'}</button><button type="button" className="secondary-action" onClick={() => save('save-draft')} disabled={savingAction !== null}>Continue Later</button>{step === totalSteps ? <button type="button" className="primary-action" onClick={() => save('submit-registration')} disabled={savingAction !== null}>{savingAction === 'submit-registration' ? 'Submitting...' : 'Submit Registration'}</button> : null}</div>
    {message ? <div className="auth-message" role="status" aria-live="polite">{message}</div> : null}
  </section>;
}
