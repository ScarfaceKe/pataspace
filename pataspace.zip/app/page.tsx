import dynamic from 'next/dynamic';

const EntryPointCards = dynamic(() => import('@/components/EntryPointCards').then((mod) => mod.EntryPointCards), {
  loading: () => <div className="skeleton-card compact" aria-label="Loading entry options" />
});
const GuidedSearch = dynamic(() => import('@/components/GuidedSearch').then((mod) => mod.GuidedSearch), {
  loading: () => <div className="skeleton-card hero-skeleton" aria-label="Loading guided search" />
});
import { FEATURED_KENYA_LOCATIONS, LOCATION_ARCHITECTURE_RULES } from '@/domain/locations';
import { BRAND_IDENTITY } from '@/domain/brand';
import { PLATFORM_FOUNDATION } from '@/domain/platform';
import { PROPERTY_CATEGORIES } from '@/domain/property-categories';
import { TRUST_PRINCIPLES } from '@/domain/trust';

export default function Home() {
  return (
    <main>
      <nav className="topbar" aria-label="Main navigation">
        <a className="brand" href="#top" aria-label="PataSpace home">
          <span aria-hidden="true">P</span>
          PataSpace
        </a>
        <div className="navlinks">
          <a href="#entry">Start</a>
          <a href="#categories">Categories</a>
          <a href="#guided">Guided search</a>
          <a href="#trust">Trust</a>
          <a href="/auth/login">Log in</a>
          <a href="/auth/register">Create account</a>
        </div>
      </nav>

      <section id="top" className="hero">
        <div className="hero-copy">
          <span className="section-eyebrow">Built for Kenya</span>
          <h1>{BRAND_IDENTITY.brandPosition}</h1>
          <p>
            {PLATFORM_FOUNDATION.projectName} helps Kenyans quickly find houses, shops, offices, and event halls through
            guided matching, verified rental listings, and intelligent support that stays behind the scenes.
          </p>
          <div className="hero-actions app-first-actions" aria-label="Start searching with PataSpace">
            <a className="primary-action" href="#entry">Begin guided search</a>
            <a className="secondary-action" href="/auth/register">Create free account</a>
          </div>
          <div className="trust-chip-row" aria-label="PataSpace trust signals">
            <span>Kenya only</span>
            <span>Verified-first</span>
            <span>M-Pesa ready</span>
          </div>
        </div>
        <div id="entry">
          <EntryPointCards />
        </div>
      </section>

      <aside className="mission-card mission-row" aria-label="PataSpace mission">
        <span>Mission</span>
        <p>{PLATFORM_FOUNDATION.mission}</p>
      </aside>

      <section id="categories" className="content-section">
        <div className="section-heading">
          <span className="section-eyebrow">Supported categories</span>
          <h2>Only four rental categories</h2>
          <p>No sales, hotels, short-stay clone workflows, or extra categories are part of this foundation.</p>
        </div>
        <div className="cards-grid">
          {PROPERTY_CATEGORIES.map((category) => (
            <article key={category.id} className="info-card">
              <h3>{category.label}</h3>
              <p>{category.description}</p>
              <ul>
                {category.supportedTypes.map((type) => (
                  <li key={type}>{type}</li>
                ))}
              </ul>
            </article>
          ))}
        </div>
      </section>

      <div id="guided" className="content-section">
        <GuidedSearch />
      </div>

      <section className="content-section">
        <div className="section-heading">
          <span className="section-eyebrow">Location architecture</span>
          <h2>Structured for every place in Kenya</h2>
          <p>
            Searches are designed around a Kenya-only hierarchy covering counties, towns, estates, suburbs, market
            centres, villages, and growing urban areas.
          </p>
        </div>
        <div className="location-strip">
          {FEATURED_KENYA_LOCATIONS.map((location) => (
            <span key={location.id}>{location.name}</span>
          ))}
        </div>
        <p className="small-note">Hierarchy rule: {LOCATION_ARCHITECTURE_RULES.hierarchy.join(' → ')}</p>
      </section>

      <section id="trust" className="content-section trust-section">
        <div className="section-heading">
          <span className="section-eyebrow">Trust first</span>
          <h2>Trust is more important than quantity</h2>
          <p>Every foundation decision is aimed at reducing fake listings, incorrect information, and frustration.</p>
        </div>
        <div className="trust-grid">
          {TRUST_PRINCIPLES.map((signal) => (
            <article key={signal.id}>
              <span aria-hidden="true">✓</span>
              <div>
                <h3>{signal.label}</h3>
                <p>{signal.description}</p>
              </div>
            </article>
          ))}
        </div>
      </section>

      <footer className="site-footer" aria-label="PataSpace footer">
        <div>
          <a className="brand footer-brand" href="#top" aria-label="PataSpace home"><span aria-hidden="true">P</span>PataSpace</a>
          <h2>About PataSpace</h2><p>Smart rental discovery built for Kenya.</p>
        </div>
        <nav aria-label="Footer quick links">
          <h2>Quick Links</h2>
          <a href="#entry">Start Search</a>
          <a href="/auth/register">Create Account</a>
          <a href="/auth/login">Log In</a>
          <a href="/dashboard/notifications">Notifications</a>
        </nav>
        <nav aria-label="Support and legal">
          <h2>Support</h2>
          <a href="/support">Contact Support</a>
          <a href="#privacy">Privacy Policy</a>
          <a href="#terms">Terms of Service</a>
        </nav>
        <div>
          <h2>Social</h2>
          <p className="social-placeholders">Facebook · Instagram · X · LinkedIn · TikTok</p>
          <p>© {new Date().getFullYear()} PataSpace. All rights reserved.</p>
        </div>
      </footer>
    </main>
  );
}
