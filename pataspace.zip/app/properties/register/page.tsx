import { PropertyRegistrationForm } from '@/components/properties/PropertyRegistrationForm';
import { canRegisterProperties } from '@/domain/property-registration';
import { requireCurrentUser } from '@/server/auth/current-user';

export const metadata = { title: 'Register Property — PataSpace' };

export default async function PropertyRegisterPage() {
  const profile = await requireCurrentUser();
  const allowed = canRegisterProperties(profile.role);

  return (
    <main className="property-registration-page">
      {allowed ? (
        <PropertyRegistrationForm profileRole={profile.role} />
      ) : (
        <section className="auth-card compact">
          <span className="section-eyebrow">Property registration</span>
          <h1>This account cannot register properties</h1>
          <p>
            Property registration is available to Property Owners, Property Managers and Leasing Agents. Customers cannot
            register properties.
          </p>
          <a className="secondary-action full-width" href="/">Back to PataSpace</a>
        </section>
      )}
    </main>
  );
}
