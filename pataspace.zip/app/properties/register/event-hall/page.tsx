import { EventHallRegistrationForm } from '@/components/event-halls/EventHallRegistrationForm';
import { canRegisterEventHalls } from '@/domain/event-hall-registration';
import { requireCurrentUser } from '@/server/auth/current-user';

export const metadata = { title: 'Event Hall Registration — PataSpace' };

export default async function EventHallRegistrationPage() {
  const profile = await requireCurrentUser();
  return (
    <main className="property-registration-page">
      {canRegisterEventHalls(profile.role) ? <EventHallRegistrationForm profileRole={profile.role} /> : <section className="auth-card compact"><span className="section-eyebrow">Event hall registration</span><h1>Customers cannot register event halls</h1><p>Event hall registration is available to Property Owners, Property Managers and Leasing Agents.</p><a className="secondary-action full-width" href="/">Back to PataSpace</a></section>}
    </main>
  );
}
