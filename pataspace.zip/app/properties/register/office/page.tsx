import { OfficeRegistrationForm } from '@/components/offices/OfficeRegistrationForm';
import { canRegisterOffices } from '@/domain/office-registration';
import { requireCurrentUser } from '@/server/auth/current-user';

export const metadata = { title: 'Office Registration — PataSpace' };

export default async function OfficeRegistrationPage() {
  const profile = await requireCurrentUser();
  return (
    <main className="property-registration-page">
      {canRegisterOffices(profile.role) ? (
        <OfficeRegistrationForm profileRole={profile.role} />
      ) : (
        <section className="auth-card compact">
          <span className="section-eyebrow">Office registration</span>
          <h1>Customers cannot register offices</h1>
          <p>Office registration is available to Property Owners, Property Managers and Leasing Agents.</p>
          <a className="secondary-action full-width" href="/">Back to PataSpace</a>
        </section>
      )}
    </main>
  );
}
