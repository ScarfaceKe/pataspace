import { HouseRegistrationForm } from '@/components/houses/HouseRegistrationForm';
import { canRegisterHouses } from '@/domain/house-registration';
import { requireCurrentUser } from '@/server/auth/current-user';

export const metadata = { title: 'House Registration — PataSpace' };

export default async function HouseRegistrationPage() {
  const profile = await requireCurrentUser();
  const allowed = canRegisterHouses(profile.role);

  return (
    <main className="property-registration-page">
      {allowed ? (
        <HouseRegistrationForm profileRole={profile.role} />
      ) : (
        <section className="auth-card compact">
          <span className="section-eyebrow">House registration</span>
          <h1>Customers cannot register houses</h1>
          <p>House registration is available to Property Owners, Property Managers and Leasing Agents.</p>
          <a className="secondary-action full-width" href="/">Back to PataSpace</a>
        </section>
      )}
    </main>
  );
}
