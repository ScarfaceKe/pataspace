import { ShopRegistrationForm } from '@/components/shops/ShopRegistrationForm';
import { canRegisterShops } from '@/domain/shop-registration';
import { requireCurrentUser } from '@/server/auth/current-user';

export const metadata = { title: 'Shop Registration — PataSpace' };

export default async function ShopRegistrationPage() {
  const profile = await requireCurrentUser();
  const allowed = canRegisterShops(profile.role);

  return (
    <main className="property-registration-page">
      {allowed ? (
        <ShopRegistrationForm profileRole={profile.role} />
      ) : (
        <section className="auth-card compact">
          <span className="section-eyebrow">Shop registration</span>
          <h1>Customers cannot register shops</h1>
          <p>Shop registration is available to Property Owners, Property Managers and Leasing Agents.</p>
          <a className="secondary-action full-width" href="/">Back to PataSpace</a>
        </section>
      )}
    </main>
  );
}
