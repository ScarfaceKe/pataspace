import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { getProfileFromSessionCookie } from '@/server/auth/service';
import { SESSION_COOKIE_NAME } from '@/server/auth/session';
import { registerPropertyFoundation } from '@/server/properties/service';

export async function POST(request: Request) {
  const cookieStore = await cookies();
  const profile = await getProfileFromSessionCookie(cookieStore.get(SESSION_COOKIE_NAME)?.value);
  if (!profile) {
    return NextResponse.json({ ok: false, message: 'Please log in to register a property.' }, { status: 401 });
  }

  const result = await registerPropertyFoundation(profile, await request.json());
  if (!result.ok) return NextResponse.json(result, { status: result.status });
  return NextResponse.json({
    ok: true,
    message: result.message,
    property: result.property,
    nextRoute: result.nextRoute
  });
}
