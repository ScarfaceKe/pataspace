import { cookies } from 'next/headers';
import { NextResponse } from 'next/server';
import { getProfileFromSessionCookie } from '@/server/auth/service';
import { SESSION_COOKIE_NAME } from '@/server/auth/session';
import { registerOfficeFoundation } from '@/server/offices/service';

export async function POST(request: Request) {
  const cookieStore = await cookies();
  const profile = await getProfileFromSessionCookie(cookieStore.get(SESSION_COOKIE_NAME)?.value);
  if (!profile) return NextResponse.json({ ok: false, message: 'Please log in to register an office.' }, { status: 401 });
  const result = await registerOfficeFoundation(profile, await request.json());
  if (!result.ok) return NextResponse.json(result, { status: result.status });
  return NextResponse.json(result);
}
